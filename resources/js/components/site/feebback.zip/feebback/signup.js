import React from 'react';
import axios from 'axios';
import {Button, Carousel ,Container ,Row,Col,Card,Tabs,Tab,Sonnet ,Form} from 'react-bootstrap';
import './../signup/signup.css';


class SignUp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fname: '',
      email: '',
      pass: '',
      conpass: '',
    }
  }

  

  handleFormSubmit = e => {
    e.preventDefault();
    

    // perform all neccassary validations
    const { pass, conpass } = this.state;
    if (pass !== conpass) {
      alert("Passwords don't match");
    } else {
        axios.post('http://localhost/api.php',this.state)

        .then(function (response) {
          console.log(response.data);
        })
        .catch(function (error) {
          console.log(error);
        });
    }

  };
  // handleFormSubmit( event ) {
  //   event.preventDefault();
  //   console.log(this.state);
  // }
  
  
    render() {
      return (
        <form action ="#" >
          <Row className="signupRow">
            <Col md={3}></Col>
              <Col md={6} className="signup">
                <h4><b>1 Day Trial </b>- Get Started Absolutely Free</h4>
                  <p>Find Out If  Works For You. Upgrade At Any Time For Unlimited Security And Privacy.</p> 
                    <br/><br/>
                    <Row className="forms">
                        <Col md={6}>
                        
                        <Form.Control type="text" placeholder="Enter Full Name" id="fname" name="full name"
                          value={this.state.fname}
                         onChange={e => this.setState({ fname: e.target.value })}
                         />
                        </Col>
                        <Col md={6}>
                        <Form.Control type="email" placeholder="Enter Email" 
                        id="email" name="Email"
                        value={this.state.email}
                       onChange={e => this.setState({ email: e.target.value })}
                        />
                        </Col>
                        <br/><br/><br/>
                        
                        <Col md={6}>
                        <Form.Control type="password" placeholder="Enter Password" 
                        id="pass" name="Password "
                        value={this.state.pass}
                       onChange={e => this.setState({ pass: e.target.value })}
                        />
                        </Col>
                        <Col md={6}>
                        <Form.Control type="password" placeholder="Confirm Password" 
                        id="conpass" name="Confirm Password "
                        value={this.state.conpass}
                       onChange={e => this.setState({ conpass: e.target.value })}
                        />
                        </Col>
                        <br/><br/><br/>
                        <p class="disclaimer-text text-center">By submitting the form you agree with our <a href="https://www.ivacy.com/legal/#privacy-policy" target="_blank"> Privacy
            Policy</a> &amp; <a href="https://www.ivacy.com/legal/#usage-terms" target="_blank">Terms
            of Usage</a></p>
            <br/><br/><br/>
                        <Col md={12} className="signup">
                        <Button className="getbtn" variant="warning" onClick={e => this.handleFormSubmit(e)} value="Submit">Start Free</Button>
                        </Col>
                    </Row>
                    
                  </Col>
                  <Col md={3} ></Col>
                </Row>
                <div>
                  {this.state.mailSent &&
                    <div>Thank you for contcting us.</div>
                  }
                </div>
          </form >
      );
    }
  }
  

  export default SignUp;
  